"""Small dirfd-relative filesystem primitives for controller-owned state.

Every configured root is walked from ``/`` one component at a time with
``O_DIRECTORY|O_NOFOLLOW``.  The resulting descriptor, rather than the lexical
path, is the authority for subsequent creates and opens.  Renaming or replacing
an ancestor therefore cannot redirect an operation.  Final files are created
exclusively, checked for type/owner/link count, and durably fsync'd.
"""

from __future__ import annotations

import errno
import os
import stat
from pathlib import Path

_DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)
_FILE_NOFOLLOW = os.O_CLOEXEC | getattr(os, "O_NOFOLLOW", 0)


class SecurePathError(OSError):
    """A configured state path could not be securely anchored."""


def _absolute_parts(path: Path | str) -> tuple[Path, tuple[str, ...]]:
    raw = Path(path).expanduser()
    if ".." in raw.parts:
        raise SecurePathError(errno.EINVAL, "state path contains traversal", str(raw))
    if not raw.is_absolute():
        raw = Path.cwd() / raw
    # Do not resolve(): following a symlink here would defeat the component walk.
    parts = tuple(part for part in raw.parts if part not in (raw.anchor, "", "."))
    return raw, parts


class SecureDir:
    """An owned directory held open by descriptor.

    Descriptors intentionally remain open for the owning harness/sink lifetime.
    ``/proc/<pid>/fd/<n>`` can then be handed to another local process as a stable
    path to the exact inode, without re-traversing replaceable ancestors.
    """

    def __init__(self, fd: int, lexical: Path) -> None:
        self.fd = fd
        self.lexical = lexical

    @classmethod
    def anchor(cls, path: Path | str, *, create: bool = True, mode: int = 0o700) -> "SecureDir":
        lexical, parts = _absolute_parts(path)
        fd = os.open("/", _DIR_FLAGS)
        try:
            for index, component in enumerate(parts):
                final = index == len(parts) - 1
                try:
                    child = os.open(component, _DIR_FLAGS, dir_fd=fd)
                except FileNotFoundError:
                    if not create:
                        raise
                    os.mkdir(component, mode if final else 0o700, dir_fd=fd)
                    os.fsync(fd)
                    child = os.open(component, _DIR_FLAGS, dir_fd=fd)
                except OSError as exc:
                    raise SecurePathError(
                        exc.errno or errno.EPERM,
                        f"unsafe state path component {component!r}: {exc.strerror or exc}",
                        str(lexical),
                    ) from exc
                info = os.fstat(child)
                if not stat.S_ISDIR(info.st_mode) or info.st_uid not in (0, os.geteuid()):
                    os.close(child)
                    raise SecurePathError(
                        errno.EPERM,
                        f"state path component {component!r} has foreign ownership",
                        str(lexical),
                    )
                # A foreign-writable non-sticky ancestor permits replacement by
                # another uid. Root-owned sticky directories (notably /tmp) are
                # valid anchors because sticky semantics prevent such replacement.
                permissions = stat.S_IMODE(info.st_mode)
                if (
                    info.st_uid != os.geteuid()
                    and permissions & 0o022
                    and not permissions & stat.S_ISVTX
                ):
                    os.close(child)
                    raise SecurePathError(
                        errno.EPERM,
                        f"state path component {component!r} is replaceable",
                        str(lexical),
                    )
                os.close(fd)
                fd = child
            result = cls(fd, lexical)
            result._verify_owned_directory(mode=mode)
            return result
        except Exception:
            os.close(fd)
            raise

    def _verify_owned_directory(self, *, mode: int = 0o700) -> None:
        info = os.fstat(self.fd)
        if not stat.S_ISDIR(info.st_mode):
            raise SecurePathError(
                errno.ENOTDIR, "state root is not a directory", str(self.lexical)
            )
        if info.st_uid != os.geteuid():
            raise SecurePathError(
                errno.EPERM, "state root is not owned by this controller", str(self.lexical)
            )
        # The descriptor identifies the inode, so tightening mode cannot be raced
        # through a swapped lexical path.
        if stat.S_IMODE(info.st_mode) != mode:
            os.fchmod(self.fd, mode)
            os.fsync(self.fd)

    @property
    def proc_path(self) -> str:
        return f"/proc/{os.getpid()}/fd/{self.fd}"

    def child_proc_path(self, name: str) -> str:
        self._name(name)
        return f"{self.proc_path}/{name}"

    @staticmethod
    def _name(name: str) -> str:
        if not name or name in (".", "..") or "/" in name or "\x00" in name:
            raise SecurePathError(errno.EINVAL, "invalid state component", name)
        return name

    def stat(self, name: str):
        return os.stat(self._name(name), dir_fd=self.fd, follow_symlinks=False)

    def exists(self, name: str) -> bool:
        try:
            self.stat(name)
            return True
        except FileNotFoundError:
            return False

    def mkdir(self, name: str, *, exclusive: bool = False, mode: int = 0o700) -> "SecureDir":
        name = self._name(name)
        try:
            os.mkdir(name, mode, dir_fd=self.fd)
            os.fsync(self.fd)
        except FileExistsError:
            if exclusive:
                raise
        child = os.open(name, _DIR_FLAGS, dir_fd=self.fd)
        result = SecureDir(child, self.lexical / name)
        result._verify_owned_directory(mode=mode)
        return result

    def rmdir(self, name: str) -> None:
        os.rmdir(self._name(name), dir_fd=self.fd)
        os.fsync(self.fd)

    def unlink(self, name: str) -> None:
        os.unlink(self._name(name), dir_fd=self.fd)
        os.fsync(self.fd)

    def create_file(self, name: str, *, mode: int = 0o600, read_write: bool = False) -> int:
        flags = (
            (os.O_RDWR if read_write else os.O_WRONLY) | os.O_CREAT | os.O_EXCL | _FILE_NOFOLLOW
        )
        fd = os.open(self._name(name), flags, mode, dir_fd=self.fd)
        self._verify_file(fd, mode=mode)
        os.fsync(self.fd)
        return fd

    def open_file(self, name: str, *, flags: int, mode: int = 0o600) -> int:
        fd = os.open(self._name(name), flags | _FILE_NOFOLLOW, mode, dir_fd=self.fd)
        self._verify_file(fd, mode=mode)
        return fd

    @staticmethod
    def _verify_file(fd: int, *, mode: int) -> None:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise SecurePathError(errno.EINVAL, "controller state file is not regular")
        if info.st_uid != os.geteuid():
            raise SecurePathError(errno.EPERM, "controller state file has foreign owner")
        if info.st_nlink != 1:
            raise SecurePathError(errno.EMLINK, "controller state file has multiple hard links")
        if stat.S_IMODE(info.st_mode) != mode:
            os.fchmod(fd, mode)

    def write_exclusive(self, name: str, data: bytes, *, mode: int = 0o600) -> int:
        fd = self.create_file(name, mode=mode, read_write=True)
        try:
            view = memoryview(data)
            while view:
                written = os.write(fd, view)
                if written <= 0:
                    raise OSError(errno.EIO, "short controller-state write")
                view = view[written:]
            os.fsync(fd)
            os.fsync(self.fd)
            os.lseek(fd, 0, os.SEEK_SET)
            return fd
        except Exception:
            os.close(fd)
            try:
                self.unlink(name)
            except OSError:
                pass
            raise

    def append_durable(self, name: str, data: bytes, *, mode: int = 0o600) -> None:
        try:
            fd = self.open_file(name, flags=os.O_WRONLY | os.O_APPEND, mode=mode)
        except FileNotFoundError:
            fd = self.create_file(name, mode=mode)
        try:
            view = memoryview(data)
            while view:
                written = os.write(fd, view)
                if written <= 0:
                    raise OSError(errno.EIO, "short audit write")
                view = view[written:]
            os.fsync(fd)
            os.fsync(self.fd)
        finally:
            os.close(fd)

    def close(self) -> None:
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1
